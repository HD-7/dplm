# _*_ coding: utf-8 _*_

import config  #импортируем файл с токеном где лежит ключ
import telebot #сама библиотека
from telebot import types
import pywapi #библиотека погоды
import postgresql #база данных
import random  #библиотека случайных чисел
slovar=['asdf','asdf']
otvet=['лучше побудь дома', 'никуда не ходи']
bot=telebot.TeleBot(config.token) #токен наш в фалике конфиг имя token

@bot.message_handler(commands=['start'])
def handle_start(message):
    user_markup=telebot.types.ReplyKeyboardMarkup(True, False)
    user_markup.row('\u2601 Погода на сегодня', '/help \U0001f631')
    user_markup.row('\U0001f31d Погода на 3 дня \U0001f31a')
    user_markup.row('\U0001f61c Расскажи анекдот', 'Задать вопрос \U0001f4ac')
    bot.send_message(message.chat.id, 'Привет, '+message.chat.first_name+' чем могу помочь?', reply_markup=user_markup)

@bot.message_handler(commands=['help'])
def handle_help(message):
    bot.send_message(message.chat.id, config.random_message())

@bot.message_handler(content_types=['text'])
def handle_anekdot(message):
    if message.text=="\U0001f61c Расскажи анекдот":
        bot.send_message(message.chat.id, config.random_anekdot())
    if message.text=="\u2601 Погода на сегодня":
        handle_krasnoyarsk(message)
    if message.text=="\U0001f31d Погода на 3 дня \U0001f31a":
        handle_krasnoyarskkk(message)
    if message.text=="Задать вопрос \U0001f4ac":
        handle_dialog(message)

@bot.message_handler(commands=['krasnoyarsk'])
def handle_krasnoyarsk(message):
    weather_com_result=pywapi.get_weather_from_weather_com('RSXX0267')
    bb=weather_com_result['current_conditions']['text']
    if bb=='Fair':
        bb='\u2600'
    weatherReport=bb+"В Красноярске сейчас "+weather_com_result['current_conditions']['temperature']+" °С "+"\n По ощущениям: "+weather_com_result['current_conditions']['feels_like']+" °С \n Влажность воздуха  "+weather_com_result['current_conditions']['humidity']+' % \n поэтому '+random.choice(otvet)
    aa=weather_com_result['current_conditions']['temperature']
    bot.send_message(message.chat.id, weatherReport)
   # bot.send_message(message.chat.id, bb)
    print(weather_com_result)
    print('..............')

@bot.message_handler(commands=['krasnoyarskkk'])
def handle_krasnoyarskkk(message):
    weather_com_result=pywapi.get_weather_from_weather_com('RSXX0267')
    result=pywapi.get_weather_from_weather_com('RSXX0267')
    a=''
    b='Погода на ближайшие дни: \n'
    for i in range(0,3):
        c=result['forecasts'][i]['day_of_week']
        d={
            c=='Monday': 'Понедельник',
            c=='Tuesday': 'Вторник',
            c=='Wednesday': 'Среда',
            c=='Thursday': 'Четверг',
            c=='Friday': 'Пятница',
            c=='Saturday': 'Суббота',
            c=='Sunday': 'Воскресенье'}[1]
        a="\n "+d+" "+"\n "+"Max: "+result['forecasts'][i]['high']+" °С \n "+"Min: "+result['forecasts'][i]['low']+" °С \n "
        b=b+a
   # weatherReport="Погода на 3 дня:"+weather_com_result['forecasts'][1]['date']+" "+weather_com_result['forecasts'][1]['day_of_week']
    bot.send_message(message.chat.id, b)
    print(weather_com_result)
    print(weather_com_result['forecasts'][1]['day_of_week'])

@bot.message_handler(commands=['otvet'])
def handle_otvet(message):
    if message.text.lower() in config.dota:
        bot.send_message(message.chat.id, config.dota[message.text.lower()])
    handle_dialog(message)

@bot.message_handler(commands=['dialog'])
def handle_dialog(message):
    user_markup=telebot.types.ReplyKeyboardMarkup(True, False)
    user_markup.row('Что там с погодой?', 'Что мне одеть сегодня?')
    user_markup.row('Как там африканские дети?', 'Вернуться в меню')
    msg=bot.send_message(message.chat.id, "Что ты хотел спросить?", reply_markup=user_markup)
    bot.register_next_step_handler(msg, name) #следующий текс без вариантов летит в name

def name(message): #вот такая у него тяжёлая судьба, а кому сейчас легко
    if message.text=="Вернуться в меню":
        handle_start(message)
    elif message.text.lower() in config.dota:
         handle_otvet(message)
    else:
         bot.send_message(message.chat.id, "Моя мозговая активность в данный момент мала, поэтому я не могу ответить на данный вопрос")
         handle_dialog(message)


if __name__=='__main__':
    bot.polling(none_stop=True, interval=0)
